package products;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProvenSoft
 */
public class Store {
    private List<Product> products;

    public Store() {
        products = new ArrayList<>();
    }
    
    /**
     * adds a product to the list
     * avoiding null products and products with existing code or null code.
     * @param product
     * @return 
     */
    public boolean addProduct(Product product) {
        boolean b = false;
        //TODO
        return b;
    }
    
    public boolean modifyProduct(Product current, Product product) {
        boolean b = false;
        //TODO
        return b;        
    }
    
    public boolean removeProduct(Product product) {
        boolean b = false;
        //TODO
        return b;         
    }
    
    public Product searchProductByCode(String code) {
        Product result = null;
        //TODO
        return result;
    }
    
    public List<Product> searchAllProducts() {
        List<Product> result = null;
        //TODO
        return result;
    }
    
    public List<Product> searchProductsWithLowStock(int stock) {
        List<Product> result = null;
        //TODO
        return result;
    }
    
    public void generateProducts() {
        products.clear();
        products.add(new Product("code01", "desc01", 11, 101));
    }
    
}
