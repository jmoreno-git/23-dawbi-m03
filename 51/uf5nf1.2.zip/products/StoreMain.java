package products;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author ProvenSoft
 */
public class StoreMain {

    private Store myStore;
    private Scanner scan;
    private boolean exit;
    
//    public StoreMain() {
//        myStore = new Store();
//        scan = new Scanner(System.in);
//    }
    
    public static void main(String[] args) {
        StoreMain sm = new StoreMain();
        sm.run();
    }

    private void run() {
        myStore = new Store();
        scan = new Scanner(System.in);
        //create menu
        Menu menu = createMenu();
        //control loop (user interaction)
        exit = false; //flag to exit program
        do {
            //show menu and get user's choice
            int option = menu.displayMenuAndGetOption();
            switch (option) {
                case 0:  //exit program
                    doExit();
                    break;
                case 1:  //search all products
                    doListAllProducts();
                    break;
                default:
                    System.out.println("Option not implemented yet!");
            }
        } while (!exit);
    }  //end of run()

    private Menu createMenu() {
        Menu mnu = new Menu("Store application");
        mnu.addOption("Exit");
        mnu.addOption("Search all products");
        mnu.addOption("Search product by code");
        mnu.addOption("Search products with low stock");
        mnu.addOption("Add a new product");
        mnu.addOption("Modify a product");
        mnu.addOption("Remove a product");
        return mnu;
    }
    
    private void displayProductList(List<Product> data) {
        for (Product product : data) {
            System.out.println(product);
        }
        System.out.printf("%d products listed%n", data.size());
    }
    
    /**
     * asks for confirmation and exits application
     */
    private void doExit() {
        //TODO ask for confirmation
        exit = true;
    }

    private void doListAllProducts() {
        List<Product> found = myStore.searchAllProducts();
        displayProductList(found);
    }
    
}
